package clase.juanmarquez.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prograna {

	public static void main(String[] args) {
		SpringApplication.run(Prograna.class, args);
	}

}
